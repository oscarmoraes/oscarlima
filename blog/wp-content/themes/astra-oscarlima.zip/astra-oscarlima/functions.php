<?php
/**
 * Astra Child Theme functions and definitions
 * Organizado de forma Orientada a Objetos para máxima legibilidade e manutenção.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra Child
 * @since 1.0.0
 */

// Evita acesso direto ao arquivo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Classe principal do Tema Filho Oscar Lima
 */
class OscarLima_Blog_Theme {

    /**
     * Instância única da classe (Singleton)
     */
    private static $instance = null;

    /**
     * Retorna a instância única da classe
     */
    public static function get_instance() {
        if ( self::$instance === null ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Construtor da classe - Registra todos os hooks do WordPress e Astra
     */
    private function __construct() {
        // Inicializa as dependências e scripts do tema
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ), 15 );
        add_action( 'wp_body_open', array( $this, 'inject_background_blobs' ) );
        add_filter( 'upload_mimes', array( $this, 'allow_svg_uploads' ) );
        
        // Configurações de layout para forçar a sidebar ativa
        add_filter( 'astra_page_layout', array( $this, 'force_sidebar_layout' ) );
        add_filter( 'astra_get_content_layout', array( $this, 'force_content_layout' ) );
        
        // Gatilhos de conversão em largura total e Chatbot
        add_action( 'astra_sidebars_before', array( $this, 'render_sticky_sidebar' ) );
        add_action( 'astra_single_header_bottom', array( $this, 'inject_single_post_header_meta' ) );
        add_action( 'astra_content_after', array( $this, 'inject_bottom_fullwidth_sections' ) );
        add_action( 'wp_footer', array( $this, 'inject_chatbot_ui' ) );

        // Desativação global de comentários e pings
        add_filter( 'comments_open', '__return_false', 20, 2 );
        add_filter( 'pings_open', '__return_false', 20, 2 );
        add_action( 'init', array( $this, 'disable_comments_support' ) );

        // Conexão do blog com a página principal (Header, Logo e Site Title)
        add_action( 'after_setup_theme', array( $this, 'setup_primary_nav_menu' ) );
        add_filter( 'get_custom_logo', array( $this, 'redirect_custom_logo_url' ) );
        add_filter( 'astra_site_title_href', array( $this, 'redirect_site_title_url' ) );

        // Imagem em Destaque Padrão / Fallback (Welcome Banner)
        add_filter( 'has_post_thumbnail', array( $this, 'fallback_has_post_thumbnail' ), 10, 3 );
        add_filter( 'post_thumbnail_html', array( $this, 'fallback_post_thumbnail_html' ), 10, 5 );
        add_filter( 'post_thumbnail_url', array( $this, 'fallback_post_thumbnail_url' ), 10, 3 );
    }

    /**
     * Enfileira folhas de estilo, scripts e FontAwesome
     */
    public function enqueue_assets() {
        // FontAwesome para ícones premium do rodapé e sidebar
        wp_enqueue_style( 
            'fontawesome', 
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', 
            array(), 
            '6.4.0' 
        );

        // Tema Pai (Astra)
        wp_enqueue_style( 
            'astra-parent-theme-css', 
            get_template_directory_uri() . '/style.css', 
            array(), 
            'all' 
        );
        
        // Tema Filho
        wp_enqueue_style( 
            'astra-child-theme-css', 
            get_stylesheet_directory_uri() . '/style.css', 
            array('astra-parent-theme-css'), 
            time(), // Cache-busting automático usando timestamp durante o desenvolvimento
            'all' 
        );
    }

    /**
     * Injeta os blobs coloridos flutuantes de fundo (Design original oscarlima.com.br)
     */
    public function inject_background_blobs() {
        echo '<!-- Background Blobs -->';
        echo '<div class="bg-blobs">';
        echo '  <div class="blob blob-1"></div>';
        echo '  <div class="blob blob-2"></div>';
        echo '</div>';
    }

    /**
     * Permite upload de arquivos SVG nativos
     */
    public function allow_svg_uploads( $mimes ) {
        $mimes['svg'] = 'image/svg+xml';
        return $mimes;
    }

    /**
     * Força o layout de barra lateral direita nos artigos individuais
     */
    public function force_sidebar_layout( $layout ) {
        if ( is_single() ) {
            return 'right-sidebar';
        }
        return $layout;
    }

    /**
     * Força o layout do contêiner para 'content-boxed-layout' nos posts.
     * Importante: Isso impede que o Astra use o modo full-width/stretched e garante 
     * o espaço necessário para renderizar o elemento de sidebar na estrutura HTML do tema.
     */
    public function force_content_layout( $layout ) {
        if ( is_single() ) {
            return 'content-boxed-layout';
        }
        return $layout;
    }

    /**
     * Injeta as seções de Prova Social e Newsletter em largura total abaixo do conteúdo e sidebar
     */
    public function inject_bottom_fullwidth_sections() {
        if ( is_single() ) {
            ?>
            <!-- Gatilhos de Conversão: Seção de Prova Social e Resultados (Workana Testimonial) -->
            <section class="oscarlima-bottom-section oscarlima-bottom-proof">
                <div class="ast-container">
                    <div class="oscarlima-post-proof glass-panel">
                        <span class="cta-badge secondary-badge">PROVA SOCIAL</span>
                        <h4>Garantia de Performance &amp; Tecnologia</h4>
                        
                        <div class="proof-stats-grid">
                            <div class="stat-item">
                                <div class="stat-icon speed-score">100</div>
                                <div class="stat-info">
                                    <strong>Google PageSpeed</strong>
                                    <span>Carregamento instantâneo para máxima retenção de leads</span>
                                </div>
                            </div>
                            <div class="stat-item">
                                <div class="stat-icon"><i class="fa-solid fa-robot"></i></div>
                                <div class="stat-info">
                                    <strong>IA Integrada &amp; Agentes</strong>
                                    <span>Automatização inteligente integrada para alavancar vendas</span>
                                </div>
                            </div>
                        </div>

                        <div class="proof-testimonial">
                            <p class="testimonial-quote">"Oscar é um dos melhores freelancers com quem trabalhei! Conhece muito, é dedicado, rápido e a entrega é superior à contratação."</p>
                            <div class="testimonial-author">
                                <div class="author-avatar">M</div>
                                <div class="author-info">
                                    <strong>Marcelo F.</strong>
                                    <span>Empresário (via Workana)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Gatilhos de Conversão: Newsletter Proeminente -->
            <section class="oscarlima-bottom-section oscarlima-bottom-newsletter">
                <div class="ast-container">
                    <div class="oscarlima-single-newsletter glass-panel">
                        <span class="cta-badge">NEWSLETTER</span>
                        <h3>Domine o Web Design &amp; IA</h3>
                        <p>Receba tutoriais práticos semanais, novidades sobre criação de agentes de IA e estratégias avançadas de conversão para alavancar seus projetos diretamente no seu e-mail.</p>
                        <form class="cta-form" action="#" method="post" onsubmit="alert('Obrigado por se inscrever! Enviaremos novidades em breve.'); return false;">
                            <input type="email" placeholder="Seu melhor e-mail" required />
                            <button type="submit">Inscrever-se</button>
                        </form>
                    </div>
                </div>
            </section>
            <?php
        }
    }

    /**
     * Remove o suporte a comentários dos posts e páginas
     */
    public function disable_comments_support() {
        remove_post_type_support( 'post', 'comments' );
        remove_post_type_support( 'page', 'comments' );
    }

    /**
     * Cria e vincula o menu primário dinamicamente contendo os links da home principal
     */
    public function setup_primary_nav_menu() {
        $menu_name = 'Primary Menu';
        $blog_home = esc_url( home_url( '/' ) );
        $saved_home = get_option( 'oscarlima_last_menu_home_url', '' );

        // Recria apenas se o menu não existir ou o endereço do site mudar (migração)
        if ( ! wp_get_nav_menu_object( $menu_name ) || $saved_home !== $blog_home ) {
            $menu_exists = wp_get_nav_menu_object( $menu_name );
            if ( $menu_exists ) {
                wp_delete_nav_menu( $menu_exists->term_id );
            }

            $menu_id = wp_create_nav_menu( $menu_name );
            $parent_root = str_replace( '/blog/', '/', $blog_home );

            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'   => 'Início',
                'menu-item-url'     => $parent_root . '#home',
                'menu-item-status'  => 'publish'
            ) );
            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'   => 'Especialidades',
                'menu-item-url'     => $parent_root . '#specialties',
                'menu-item-status'  => 'publish'
            ) );
            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'   => 'Performance',
                'menu-item-url'     => $parent_root . '#performance',
                'menu-item-status'  => 'publish'
            ) );
            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'   => 'Portfólio',
                'menu-item-url'     => $parent_root . '#portfolio',
                'menu-item-status'  => 'publish'
            ) );
            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'   => 'Depoimentos',
                'menu-item-url'     => $parent_root . '#testimonials',
                'menu-item-status'  => 'publish'
            ) );
            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'   => 'Blog',
                'menu-item-url'     => $blog_home,
                'menu-item-status'  => 'publish'
            ) );
            wp_update_nav_menu_item( $menu_id, 0, array(
                'menu-item-title'   => 'Contato',
                'menu-item-url'     => $parent_root . '#contact',
                'menu-item-status'  => 'publish'
            ) );

            $locations = get_theme_mod( 'nav_menu_locations' );
            $locations['primary'] = $menu_id;
            set_theme_mod( 'nav_menu_locations', $locations );

            update_option( 'oscarlima_last_menu_home_url', $blog_home );
        }
    }

    /**
     * Redireciona o link do logo customizado do blog para a página principal (root)
     */
    public function redirect_custom_logo_url( $html ) {
        $blog_home = esc_url( home_url( '/' ) ); // e.g. http://localhost/oscarlima/blog/
        $parent_root = str_replace( '/blog/', '/', $blog_home ); // e.g. http://localhost/oscarlima/
        
        // Substitui a URL do link no HTML do logo customizado
        $html = str_replace( 'href="' . $blog_home . '"', 'href="' . $parent_root . '"', $html );
        $html = str_replace( 'href=\'' . $blog_home . '\'', 'href=\'' . $parent_root . '\'', $html );
        
        return $html;
    }

    /**
     * Redireciona o link do título do site do blog para a página principal (root)
     */
    public function redirect_site_title_url( $url ) {
        $blog_home = esc_url( home_url( '/' ) );
        $parent_root = str_replace( '/blog/', '/', $blog_home );
        return $parent_root;
    }

    /**
     * Força has_post_thumbnail a retornar true para posts do blog (para exibir o fallback de boas-vindas)
     */
    public function fallback_has_post_thumbnail( $has_thumbnail, $post, $thumbnail_id ) {
        if ( ! $has_thumbnail ) {
            $post_obj = get_post( $post );
            if ( $post_obj && get_post_type( $post_obj ) === 'post' ) {
                return true;
            }
        }
        return $has_thumbnail;
    }

    /**
     * Injeta a imagem de boas-vindas padrão como HTML da imagem de destaque caso não haja uma cadastrada
     */
    public function fallback_post_thumbnail_html( $html, $post_id, $post_thumbnail_id, $size, $attr ) {
        if ( ! $post_thumbnail_id ) {
            $default_url = get_stylesheet_directory_uri() . '/welcome-banner.png';
            $html = '<img src="' . esc_url( $default_url ) . '" class="attachment-large size-large wp-post-image default-fallback-featured" alt="' . esc_attr( get_the_title( $post_id ) ) . '" itemprop="image" decoding="async" />';
        }
        return $html;
    }

    /**
     * Filtra a URL da imagem de destaque padrão para retornar o caminho da imagem de boas-vindas
     */
    public function fallback_post_thumbnail_url( $thumbnail_url, $post, $size ) {
        if ( ! $thumbnail_url ) {
            $post_obj = get_post( $post );
            if ( $post_obj && get_post_type( $post_obj ) === 'post' ) {
                return get_stylesheet_directory_uri() . '/welcome-banner.png';
            }
        }
        return $thumbnail_url;
    }

    /**
     * Injeta metadados de autoridade e tempo de leitura no topo dos posts individuais
     */
    public function inject_single_post_header_meta() {
        if ( is_single() ) {
            global $post;
            $word_count = str_word_count( strip_tags( $post->post_content ) );
            $reading_time = ceil( $word_count / 200 );
            if ( $reading_time < 1 ) {
                $reading_time = 1;
            }
            ?>
            <div class="oscarlima-author-meta">
                <div class="meta-author-avatar">OL</div>
                <div class="meta-author-details">
                    <span class="meta-author-by">Escrito por <strong>Oscar Lima Bot</strong></span>
                    <span class="meta-author-subtitle">Mestre da Preguiça Eficiente</span>
                </div>
                <div class="meta-reading-time">
                    <i class="fa-regular fa-clock" style="margin-right: 5px;"></i>
                    <span>Leitura de <?php echo $reading_time; ?> min</span>
                </div>
            </div>

            <?php if ( has_post_thumbnail() ) : ?>
                <div class="oscarlima-single-featured-image">
                    <?php the_post_thumbnail( 'large', array( 'alt' => get_the_title() ) ); ?>
                </div>
            <?php endif; ?>
            <?php
        }
    }

    /**
     * Renderiza a barra lateral de conversão personalizada (Sticky)
     */
    public function render_sticky_sidebar() {
        ?>
        <div class="oscarlima-sticky-sidebar">
            <!-- Widget 1: Bio / Autoridade (Reorganizado com Header e Sociais) -->
            <div class="oscarlima-sidebar-widget oscarlima-bio-card">
                <div class="oscarlima-bio-header">
                    <div class="bio-avatar">OL</div>
                    <div class="bio-name-area">
                        <h4>Oscar Lima Bot</h4>
                        <span class="bio-title">Desenvolvedor por Curiosidade</span>
                    </div>
                </div>
                <p class="bio-desc">Não sou formado em nada, sou 100% autodidata e preguiçoso demais para fazer tarefas repetitivas. Meu primeiro contato com o mundo digital foi no curso do Jonathan Taioba sobre como criar blogs. Anos depois, finalmente tirei esse projeto do papel usando a Inteligência Artificial para automatizar tudo.</p>
                <div class="oscarlima-bio-socials">
                    <a href="https://wa.me/5521991061796" target="_blank" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="mailto:contato@oscarlima.com.br" aria-label="Email"><i class="fa-solid fa-envelope"></i></a>
                    <a href="https://linkedin.com" target="_blank" aria-label="LinkedIn"><i class="fa-brands fa-linkedin"></i></a>
                    <a href="https://github.com" target="_blank" aria-label="GitHub"><i class="fa-brands fa-github"></i></a>
                </div>
            </div>

            <!-- Widget 2: Proposta Comercial / Serviços (Com lista de benefícios) -->
            <div class="oscarlima-sidebar-widget oscarlima-cta-widget">
                <span class="widget-badge">SOLUÇÕES PREMIUM</span>
                <h4>Projetos e Consultoria</h4>
                <p class="widget-subtitle">Acelere seu negócio com soluções sob medida:</p>
                <ul class="oscarlima-service-list">
                    <li><i class="fa-solid fa-circle-check"></i> Landing Pages Ultra Rápidas</li>
                    <li><i class="fa-solid fa-circle-check"></i> Integração de Agentes de IA</li>
                    <li><i class="fa-solid fa-circle-check"></i> Automação de Processos</li>
                    <li><i class="fa-solid fa-circle-check"></i> SEO &amp; Performance Extrema</li>
                </ul>
                <a href="https://wa.me/5521991061796" class="cta-whatsapp-btn" target="_blank">
                    <svg class="whatsapp-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" width="16" height="16" fill="currentColor" style="margin-right: 8px; vertical-align: -2px;"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"/></svg>
                    Falar com Oscar no WhatsApp
                </a>
            </div>
        </div>
        <?php
    }

    /**
     * Injeta a interface e a lógica do Chatbot de IA no rodapé
     */
    public function inject_chatbot_ui() {
        ?>
        <!-- Chatbot Floating UI -->
        <button id="chatbot-trigger" class="chatbot-trigger" aria-label="Abrir Chat Inteligente">
            <i class="fa-solid fa-brain" style="font-size: 1.5rem;"></i>
        </button>
     
        <div id="chatbot-panel" class="chatbot-panel glass-panel">
            <div class="chatbot-header">
                <div class="chatbot-user">
                    <div class="chatbot-avatar">OL</div>
                    <div class="chatbot-status">
                        <h4>Oscar Lima (IA)</h4>
                        <p>Online</p>
                    </div>
                </div>
                <button id="chatbot-close" class="chatbot-close" aria-label="Fechar Chat"><i class="fa-solid fa-xmark"></i></button>
            </div>
            <div id="chatbot-messages" class="chatbot-messages">
                <div class="chat-bubble bot">
                    Olá! Sou a Inteligência Artificial do Oscar Lima. 
                    Estou aqui para tirar suas dúvidas sobre criação de sites, estimativa de prazos ou otimização de velocidade de forma direta e sem termos técnicos complexos. 
                    O que você deseja construir para o seu negócio?
                </div>
            </div>
            <div class="chatbot-suggestions">
                <button class="suggestion-btn">Quero um orçamento</button>
                <button class="suggestion-btn">Otimizar velocidade</button>
                <button class="suggestion-btn">WordPress ou React?</button>
            </div>
            <div class="chatbot-input-area">
                <input type="text" id="chatbot-input" class="chatbot-input" placeholder="Digite sua mensagem...">
                <button id="chatbot-send" class="chatbot-send" aria-label="Enviar mensagem"><i class="fa-solid fa-paper-plane"></i></button>
            </div>
        </div>

        <!-- Controlador do Chatbot com chamada relativa para a API do Oscar -->
        <script>
        document.addEventListener('DOMContentLoaded', function() {
            const chatbotTrigger = document.getElementById('chatbot-trigger');
            const chatbotPanel = document.getElementById('chatbot-panel');
            const chatbotClose = document.getElementById('chatbot-close');
            const chatbotMessages = document.getElementById('chatbot-messages');
            const chatbotInput = document.getElementById('chatbot-input');
            const chatbotSend = document.getElementById('chatbot-send');
            const suggestionBtns = document.querySelectorAll('.suggestion-btn');

            if (chatbotTrigger && chatbotPanel) {
                chatbotTrigger.addEventListener('click', () => {
                    chatbotPanel.classList.toggle('open');
                    if (chatbotPanel.classList.contains('open') && chatbotInput) {
                        chatbotInput.focus();
                    }
                });

                if (chatbotClose) {
                    chatbotClose.addEventListener('click', () => {
                        chatbotPanel.classList.remove('open');
                    });
                }

                window.addEventListener('keydown', (e) => {
                    if (e.key === 'Escape' && chatbotPanel.classList.contains('open')) {
                        chatbotPanel.classList.remove('open');
                    }
                });

                const appendMessage = (text, sender, isHtml = false) => {
                    if (!chatbotMessages) return;
                    const bubble = document.createElement('div');
                    bubble.classList.add('chat-bubble', sender);
                    if (isHtml) {
                        bubble.innerHTML = text;
                    } else {
                        bubble.textContent = text;
                    }
                    chatbotMessages.appendChild(bubble);
                    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
                    return bubble;
                };

                const showTypingIndicator = () => {
                    if (!chatbotMessages) return;
                    const typing = document.createElement('div');
                    typing.classList.add('chat-bubble', 'bot', 'chat-typing');
                    typing.id = 'chat-typing-indicator';
                    typing.innerHTML = '<span></span><span></span><span></span>';
                    chatbotMessages.appendChild(typing);
                    chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
                };

                const removeTypingIndicator = () => {
                    const indicator = document.getElementById('chat-typing-indicator');
                    if (indicator) indicator.remove();
                };

                const sendMessageToAI = async (messageText) => {
                    if (!messageText.trim()) return;

                    appendMessage(messageText, 'user');
                    if (chatbotInput) chatbotInput.value = '';
                    showTypingIndicator();

                    try {
                        const response = await fetch('../api/chat.php', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify({ message: messageText })
                        });
                        
                        const data = await response.json();
                        removeTypingIndicator();
                        
                        if (data && data.response) {
                            appendMessage(data.response, 'bot', true);
                        } else {
                            appendMessage('Desculpe, ocorreu um erro de resposta.', 'bot');
                        }
                    } catch (error) {
                        removeTypingIndicator();
                        appendMessage('Desculpe, ocorreu um erro de conexão.', 'bot');
                    }
                };

                if (chatbotSend) {
                    chatbotSend.addEventListener('click', () => {
                        if (chatbotInput) sendMessageToAI(chatbotInput.value);
                    });
                }

                if (chatbotInput) {
                    chatbotInput.addEventListener('keydown', (e) => {
                        if (e.key === 'Enter') {
                            sendMessageToAI(chatbotInput.value);
                        }
                    });
                }

                suggestionBtns.forEach(btn => {
                    btn.addEventListener('click', () => {
                        sendMessageToAI(btn.textContent);
                    });
                });
            }
        });
        </script>
        <?php
    }
}

// Inicializa a classe única do Tema Filho
OscarLima_Blog_Theme::get_instance();

